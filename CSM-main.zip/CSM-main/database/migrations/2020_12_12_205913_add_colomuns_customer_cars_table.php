<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddColomunsCustomerCarsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('customer_cars', function (Blueprint $table) {
            $table->integer('customer_branch_id')->after('customer_id');
            $table->integer('category_id')->after('chassis');
            $table->integer('model')->change();
            $table->string('year')->after('model');
            $table->string('license')->after('plate');


        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('customer_cars', function (Blueprint $table) {
            $table->dropColumn('customer_branch_id');
            $table->dropColumn('category_id');
            $table->dropColumn('year');
            $table->dropColumn('license');
        });
    }
}
