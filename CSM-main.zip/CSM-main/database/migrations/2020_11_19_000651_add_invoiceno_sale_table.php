<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddInvoicenoSaleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('sales', function (Blueprint $table) {
            $table->string('invoice_no')->after('reference_no')->nullable();
            $table->float('whts')->nullable()->default(0)->after('wht');
            $table->float('vat')->nullable()->default(0)->change();
            $table->float('wht')->nullable()->default(0)->change();
        });
    }


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('sales', function (Blueprint $table) {
            $table->dropColumn('invoice_no');
            $table->dropColumn('whts');
        });
    }
}
