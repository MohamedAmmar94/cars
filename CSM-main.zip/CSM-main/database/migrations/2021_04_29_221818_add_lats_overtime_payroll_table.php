<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AddLatsOvertimePayrollTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('payrolls', function (Blueprint $table) {
            $table->date('date')->after('id');
            $table->float('penalties')->after('user_id');
            $table->float('overtime')->after('penalties');
            $table->string('cheque_no')->after('paying_method')->nullable();
            $table->string('status')->default('Not Paid')->after('cheque_no');
            $table->string('paying_method')->nullable()->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('payrolls', function (Blueprint $table) {
            $table->dropColumn('date');
            $table->dropColumn('penalties');
            $table->dropColumn('overtime');
            $table->dropColumn('cheque_no');
            $table->dropColumn('status');
        });
    }
}
