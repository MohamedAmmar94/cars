<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    protected $fillable =[
        "name", "image", "department_id", "email", "fp_id", "phone_number",
        "user_id", "address", "city", "country","salary", "is_active", "national_id", "insurance_id"
    ];

    public function payroll()
    {
    	return $this->hasMany('App\Payroll');
    }

    public function attendance()
    {
        return $this->hasMany(Attendance::class);
    }

    public function documents()
    {
    	return $this->hasMany(EmployeeDocument::class);
    }
    
}
