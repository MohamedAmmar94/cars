<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerBranch extends Model
{
    protected $fillable =[
        "customer_id", "name"
    ];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }
}
