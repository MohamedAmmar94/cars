<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Supplier extends Model
{
    protected $fillable =[

        "name", "image", "company_name", "vat_number",
        "email", "phone_number", "address", "city",'balance',
        "state", "postal_code", "country", "is_active","type",'code'
        
    ];

    public function product()
    {
    	return $this->hasMany('App/Product');
    	
    }
    public function payments(){
        return $this->hasMany(SupplierPayment::class,'supplier_id');
    }
    public function repairscost(){
        return $this->hasMany(ExRepair::class);
    }
}
