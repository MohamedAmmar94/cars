<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asset extends Model
{
    protected $fillable = [
        "reference_no", "name", "purchase_amount","sell_amount","paid","payment_status", "note","status"
    ];

    public function payments()
    {
        return $this->hasMany(AssetPayment::class)->where('type','purchased');
    }

    public function receivedPayments()
    {
        return $this->hasMany(AssetPayment::class)->where('type','sold');;
    }
}
