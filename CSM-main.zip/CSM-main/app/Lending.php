<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lending extends Model
{
    protected $fillable = [
        "reference_no", "employee_id", "amount","paid", "payment_method" ,"payment_status", "cheque_no", "note"
    ];

    public function employee()
    {
        return $this->belongsTo(Employee::class);
    }

    public function payments()
    {
        return $this->hasMany(LendingPayment::class);
    }

}
