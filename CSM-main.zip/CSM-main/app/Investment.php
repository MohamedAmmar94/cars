<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Investment extends Model
{
    protected $fillable = [
        "reference_no", "investor_id", "amount","paid", "payment_method","payment_status", "cheque_no", "note"
    ];

    public function investor()
    {
        return $this->belongsTo(Investor::class);
    }

    public function payments()
    {
        return $this->hasMany(InvestmentPayment::class);
    }



}



