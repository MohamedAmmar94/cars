<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ImportedSale extends Model
{
    public function sale()
    {
        return $this->belongsTo(Sale::class);
    }
    public function imported_product()
    {
        return $this->belongsTo(ImportedProducts::class,'imported_products_id');
    }
}
