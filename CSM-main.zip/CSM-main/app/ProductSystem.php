<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductSystem extends Model
{
    protected $guarded = [];


    /**
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function product()
    {
        return $this->hasMany(Product::class);
    }
    public function canDeleted()
    {
        $products= Product::where('product_system_id', $this->id)->whereHas('purchases')->whereHas('sales')->get();
        if($products->count()>0)
            return  true;
        return false;
    }
}
