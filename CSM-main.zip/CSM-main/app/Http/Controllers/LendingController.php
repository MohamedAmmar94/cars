<?php

namespace App\Http\Controllers;

use App\Lending;
use App\LendingPayment;
use App\Employee;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Auth;

class LendingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if ($role->hasPermissionTo('expenses-index')) {
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if (empty($all_permission))
                $all_permission[] = 'dummy text';

            $employees = Employee::where('is_active', true)->get();

            $lims_expense_all=Lending::all();

            return view('lending.index', compact('employees','lims_expense_all', 'all_permission'));
        } else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();

        $last_serial=Lending::where("reference_no",'LIKE',"#Len-%")->orderBy("reference_no","desc")->first();
        if(!empty($last_serial)){
            $arr=explode("#Len-",$last_serial->reference_no);
            //dd($arr);
            $new_serial=(int)$arr[1] +1;
            $new_serial=str_pad($new_serial, 5, '0', STR_PAD_LEFT);

            $new_arr=["#Len-",$new_serial];
            $new_serial=implode($new_arr);
        }else{
            $new_serial="#Len-00001";
        }


//        $data['reference_no'] = 'In-' . date("Ymd") . '-' . date("his");
        $data['reference_no'] = $new_serial;
        Lending::create($data);
        return redirect('lendings')->with('message', 'Data inserted successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $role = Role::firstOrCreate(['id' => Auth::user()->role_id]);
        if ($role->hasPermissionTo('expenses-edit')) {
            $lims_expense_data = Lending::find($id);
            return $lims_expense_data;
        } else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $lims_expense_data = Lending::find($data['expense_id']);

        if($request->amount > $lims_expense_data->paid ) {
            $data['payment_status'] = 1;
        }

        $lims_expense_data->update($data);
        return redirect('lendings')->with('message', 'Data updated successfully');
    }

    public function addpayment(Request $request, $id)
    {

        $lendingPayment=new LendingPayment;
        $lendingPayment->lending_id=$request->lending_id;
        $lendingPayment->amount=$request->amount;
        $lendingPayment->payment_method=$request->payment_method;
        $lendingPayment->cheque_no=$request->cheque_no;
        $lendingPayment->note=$request->note;
        $lendingPayment->save();


        $lending=Lending::find($request->lending_id);

        if($request->amount>0 and $request->amount<($lending->amount-$lending->paid))
        {
            $pyment_status=1;
        }
        elseif ($request->amount==($lending->amount-$lending->paid) )
        {
            $pyment_status=2;
        }
        else { $pyment_status=0;}

        $lending->paid=$lending->paid+$request->amount;
        $lending->payment_status=$pyment_status;
        $lending->save();

        return redirect('lendings')->with('message', 'Data updated successfully');
    }

    public function deletePayment($id)
    {
        $payment=LendingPayment::find($id);

        if($payment->amount == $payment->lending->paid)
        {
            $pyment_status=0;
        }
        elseif ($payment->amount<$payment->lending->paid )
        {
            $pyment_status=1;
        }


        $payment->lending->paid=$payment->lending->paid-$payment->amount;
        $payment->lending->payment_status=$pyment_status;
        $payment->lending->save();

        $payment->delete();

        return redirect('lendings')->with('message', 'Payment Deleted successfully');
    }

    public function deleteBySelection(Request $request)
    {
        $expense_id = $request['expenseIdArray'];
        foreach ($expense_id as $id) {
            $lims_expense_data = Lending::find($id);
            $lims_expense_data->delete();
        }
        return 'Lending deleted successfully!';
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $lims_expense_data = Lending::find($id);
        $lims_expense_data->delete();
        return redirect('lendings')->with('not_permitted', 'Data deleted successfully');
    }
}
