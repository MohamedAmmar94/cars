<?php

namespace App\Http\Controllers;

use App\IncomeCategory;
use Illuminate\Http\Request;
use App\Income;
use App\Account;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Auth;
use DB;

class IncomeController extends Controller
{
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if ($role->hasPermissionTo('expenses-index')) {
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if (empty($all_permission))
                $all_permission[] = 'dummy text';
            $lims_account_list = Account::where('is_active', true)->get();

            if (Auth::user()->role_id > 2 && config('staff_access') == 'own')
                $lims_expense_all = Income::orderBy('id', 'desc')->where('user_id', Auth::id())->get();
            else
                $lims_expense_all = Income::orderBy('id', 'desc')->get();

            $lims_income_category_list = IncomeCategory::where('is_active', true)->get();

            return view('income.index', compact('lims_account_list', 'lims_expense_all', 'all_permission','lims_income_category_list'));
        } else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $data = $request->all();

        $last_serial=Income::where("reference_no",'LIKE',"#In-%")->orderBy("reference_no","desc")->first();
        if(!empty($last_serial)){
            $arr=explode("#In-",$last_serial->reference_no);
            //dd($arr);
            $new_serial=(int)$arr[1] +1;
            $new_serial=str_pad($new_serial, 5, '0', STR_PAD_LEFT);

            $new_arr=["#In-",$new_serial];
            $new_serial=implode($new_arr);
        }else{
            $new_serial="#In-00001";
        }


//        $data['reference_no'] = 'In-' . date("Ymd") . '-' . date("his");
        $data['reference_no'] = $new_serial;
        $data['user_id'] = Auth::id();
        Income::create($data);
        return redirect('incomes')->with('message', 'Data inserted successfully');
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        $role = Role::firstOrCreate(['id' => Auth::user()->role_id]);
        if ($role->hasPermissionTo('expenses-edit')) {
            $lims_expense_data = Income::find($id);
            return $lims_expense_data;
        } else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function update(Request $request, $id)
    {
        $data = $request->all();
        $lims_expense_data = Income::find($data['expense_id']);
        $lims_expense_data->update($data);
        return redirect('incomes')->with('message', 'Data updated successfully');
    }

    public function deleteBySelection(Request $request)
    {
        $expense_id = $request['expenseIdArray'];
        foreach ($expense_id as $id) {
            $lims_expense_data = Income::find($id);
            $lims_expense_data->delete();
        }
        return 'Incomes deleted successfully!';
    }

    public function destroy($id)
    {
        $lims_expense_data = Income::find($id);
        $lims_expense_data->delete();
        return redirect('incomes')->with('not_permitted', 'Data deleted successfully');
    }
}
