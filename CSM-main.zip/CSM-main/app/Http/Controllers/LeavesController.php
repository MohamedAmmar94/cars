<?php

namespace App\Http\Controllers;

use App\Attendance;
use App\Employee;
use App\HrmSetting;
use App\Leave;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Auth;
use DB;
use Spatie\Permission\Models\Permission;

class LeavesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('attendance')) {
            $lims_employee_list = Employee::where('is_active', true)->get();
            $lims_hrm_setting_data = HrmSetting::latest()->first();
            $general_setting = DB::table('general_settings')->latest()->first();
            if(Auth::user()->role_id > 2 && $general_setting->staff_access == 'own')
                $lims_attendance_all = Leave::orderBy('id', 'desc')->where('user_id', Auth::id())->get();
            else
                $lims_attendance_all = Leave::orderBy('id', 'desc')->get();
            return view('attendance.leaves', compact('lims_employee_list', 'lims_hrm_setting_data', 'lims_attendance_all'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();
        $employee_id =  $data['employee_id'];
        $lims_hrm_setting_data = HrmSetting::latest()->first();
        $checkin = $lims_hrm_setting_data->checkin;
        foreach ($employee_id as $id) {
            $data['date'] = date('Y-m-d', strtotime(str_replace('/', '-', $data['date'])));
            $data['user_id'] = Auth::id();
            $lims_attendance_data = Leave::whereDate('date', $data['date'])->where('employee_id', $id)->first();
            if(!$lims_attendance_data){
                $data['employee_id'] = $id;

                Leave::create($data);
            }
        }
        return redirect()->back()->with('message', 'Leave created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function deleteBySelection(Request $request)
    {
        $attendance_id = $request['attendanceIdArray'];
        foreach ($attendance_id as $id) {
            $lims_attendance_data = Leave::find($id);
            $lims_attendance_data->delete();
        }
        return 'Leaves deleted successfully!';
    }

        public function destroy($id)
    {
        $lims_attendance_data = Leave::find($id);
        $lims_attendance_data->delete();
        return redirect()->back()->with('not_permitted', 'Leave deleted successfully');
    }
}
