<?php

namespace App\Http\Controllers;

use Spatie\Permission\Models\Role;
use Auth;
use App\Investor;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class InvestorsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('investors-index')){
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if(empty($all_permission))
                $all_permission[] = 'dummy text';
            $investors = Investor::where('is_active', true)->get();
            return view('investors.index', compact('investors', 'all_permission'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('investors-add')){
            return view('investors.create');
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */

    public function store(Request $request)
    {
        $check=Investor::where('phone_number',$request->phone_number)
            ->where('email',$request->email)->where('is_active',false)->first();

        if(isset($check->id))
        {
            $check->is_active=true;
            $check->save();
            $message = 'Investor  Reactivated successfully';
            return redirect('investors')->with('message', $message);
        }
        else {
            $data = $request->all();
            $message = 'Investor created successfully';

            //validation in employee table
            $this->validate($request, [
                'phone_number' => [
                    'max:15',
                    Rule::unique('investors'),
                ], 'email' => [
                    'email',
                    'max:255',
                    Rule::unique('investors'),
                ],
            ]);


            $data['name'] = $data['employee_name'];
            $data['is_active'] = true;
            $employee = Investor::create($data);

            return redirect('investors')->with('message', $message);
        }
    }


    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $lims_employee_data = Investor::find($request['employee_id']);

        //validation in employee table
        $this->validate($request, [
            'phone_number' => [
                'max:15',
                Rule::unique('investors')->ignore($lims_employee_data->id),
            ],
            'email' => [
                'email',
                'max:255',
                Rule::unique('investors')->ignore($lims_employee_data->id),
            ],
        ]);

        $data = $request->all();

        $lims_employee_data->update($data);
        return redirect('investors')->with('message', 'Investor updated successfully');
    }



    public function deleteBySelection(Request $request)
    {
        $employee_id = $request['employeeIdArray'];
        foreach ($employee_id as $id) {
            $lims_employee_data = Investor::find($id);
            $lims_employee_data->is_active = false;
            $lims_employee_data->save();
        }
        return 'Investor deleted successfully!';
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $lims_employee_data = Investor::find($id);
        $lims_employee_data->is_active = false;
        $lims_employee_data->save();
        return redirect('investors')->with('not_permitted', 'Investor deleted successfully');
    }
}
