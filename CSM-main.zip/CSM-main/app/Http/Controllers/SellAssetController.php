<?php

namespace App\Http\Controllers;

use App\Asset;
use App\AssetPayment;
use App\Http\Requests\PurchasingAssetRequest;
use App\Http\Requests\SellAssetRequest;
use App\Investment;
use App\InvestmentPayment;
use App\Investor;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;

class SellAssetController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
            $assets            =Asset::where('status','sold')->get();
            $purchasedAssets   =Asset::where('status','purchased')->where('payment_status','2')->get();

            return view('sellAsset.index', compact('assets','purchasedAssets'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(SellAssetRequest  $request)
    {
       $asset= Asset::findOrFail($request->asset_id);
       $asset->sell_amount=$request->sell_amount;
       $asset->status='sold';
       $asset->paid=0;
       $asset->payment_status=0;
       $asset->save();

        return redirect('sell-assets')->with('message', 'Data inserted successfully');
    }



    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
            $lims_expense_data = Asset::findOrFail($id);
            return $lims_expense_data;
     }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $lims_expense_data = Asset::find($data['asset_id']);

        if($request->sell_amount < $lims_expense_data->paid ) {
            $data['payment_status'] = 1;
        }else{
            $data['payment_status'] = 2;
        }

        $lims_expense_data->update($data);
        return redirect('sell-assets')->with('message', 'Data updated successfully');
    }
    public function addpayment(Request $request, $id)

    {
        $investmentPayment=new AssetPayment();
        $investmentPayment->asset_id=$request->asset_id;
        $investmentPayment->amount=$request->amount ;
        $investmentPayment->payment_method=$request->payment_method;
        $investmentPayment->cheque_no=$request->cheque_no;
        $investmentPayment->note=$request->note;
        $investmentPayment->type='sold';
        $investmentPayment->save();


        $investment=Asset::find($request->asset_id);

        if($request->amount>0 and $request->amount<($investment->sell_amount-$investment->paid))
        {
            $pyment_status=1;
        }
        elseif ($request->amount==($investment->sell_amount-$investment->paid) )
        {
            $pyment_status=2;
        }
        else { $pyment_status=0;}

        $investment->paid=$investment->paid+$request->amount;
        $investment->payment_status=$pyment_status;
        $investment->save();

        return redirect('sell-assets')->with('message', 'Data updated successfully');
    }

    public function deletePayment($id)
    {
        $payment=AssetPayment::find($id);

        if($payment->amount == $payment->asset->paid)
        {
            $pyment_status=0;
        }
        elseif ($payment->amount<$payment->asset->paid )
        {
            $pyment_status=1;
        }


        $payment->asset->paid=$payment->asset->paid-$payment->amount;
        $payment->asset->payment_status=$pyment_status;
        $payment->asset->save();

        $payment->delete();

        return redirect('sell-assets')->with('message', 'Payment Deleted successfully');
    }

    public function deleteBySelection(Request $request)
    {
        $expense_id = $request['expenseIdArray'];
        foreach ($expense_id as $id) {
            $lims_expense_data = Asset::find($id);
            $lims_expense_data->delete();
        }
        return 'Asset deleted successfully!';
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $lims_expense_data = Asset::find($id);
        $lims_expense_data->delete();
        return redirect('sell-assets')->with('not_permitted', 'Data deleted successfully');
    }
}
