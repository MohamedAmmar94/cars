<?php

namespace App\Http\Controllers;

use App\Biller;
use App\Customer;
use App\ExRepair;
use App\Product_Sale;
use App\Sale;
use App\Supplier;
use App\SupplierPayment;
use App\Tax;
use App\Warehouse;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Auth;

class ExRepairsController extends Controller
{

    public function repairs($sale_id){
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('stockorder-edit')){
            $lims_supplier_list = Supplier::where('is_active', true)->where('type','exr')->get();
            $repairs = ExRepair::where('sale_id',$sale_id)->get();
            return view('workorder.repairs',compact('lims_supplier_list','repairs','sale_id' ));
        }
    }
    public function create($sale_id,Request $request){
        $ex_repair = new ExRepair();
        $ex_repair->sale_id = $sale_id;
        $ex_repair->supplier_id = $request->supplier;
        $ex_repair->title = $request->name;
        $ex_repair->cost = $request->cost;
        $ex_repair->paid = $request->paid;
        $ex_repair->price = $request->price;
        $ex_repair->quantity = $request->quantity;
        $ex_repair->save();
        $payments = new SupplierPayment();
        $payments->supplier_id = $request->supplier;
        $payments->payment = $request->paid;
        $payments->save();
        return back();
    }
    public function delete($id){
        $exrepair = ExRepair::find($id);
        $exrepair->delete();
        return back();
    }
}
