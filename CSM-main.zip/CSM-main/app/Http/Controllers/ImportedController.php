<?php

namespace App\Http\Controllers;

use App\ExRepair;
use App\ImportedProducts;
use App\ImportedSale;
use App\Product_Sale;
use App\Purchase;
use App\Supplier;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Auth;

class ImportedController extends Controller
{

    public function index(){
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('stockorder-edit')){
            $lims_supplier_list = Supplier::where('is_active', true)->where('type','normal')->get();

            return view('imported.imported',compact('lims_supplier_list' ));
        }
    }
    public function create(Request $request){
        $purchuse=new Purchase;
        $purchuse->reference_no='pr-' . date("Ymd") . '-'. date("his");
        $purchuse->user_id=Auth::id();
        $purchuse->warehouse_id=1;
        $purchuse->supplier_id=$request->supplier_id;
        $purchuse->item=1;
        $purchuse->total_qty=1;
        $purchuse->total_discount=0;
        $purchuse->total_tax=0;
        $purchuse->total_cost=$request->cost;
        $purchuse->grand_total=$request->cost;
        $purchuse->paid_amount=0;
        $purchuse->status=1;
        $purchuse->payment_status=1;
        $purchuse->is_imported=1;
        $purchuse->save();

        $imported=new ImportedProducts;
        $imported->purchase_id=$purchuse->id;
        $imported->name=$request->name;
        $imported->cost=$request->cost;
        $imported->remaining=$request->cost;
        $imported->status=1;
        $imported->save();

        return redirect('purchases')->with('message', 'Purchase created successfully');

    }


    public function imports($sale_id){
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('stockorder-edit')){
            $lims_imported_products_list = ImportedProducts::where('status',1)->get();
            $imported_sale = ImportedSale::where('sale_id',$sale_id)->get();
            return view('workorder.imported',compact('lims_imported_products_list','imported_sale','sale_id' ));
        }
    }
    public function store($sale_id,Request $request){

        $imported_product=ImportedProducts::find($request->imported_products_id);
        $cost = 0;
        if($imported_product->remaining > 0){
            $cost = round($request->price * 80/100,2);
            if($imported_product->remaining < $cost){
                $cost = $imported_product->remaining;
            }
        }
        $revenue = $request->price - $cost;
        $imported_product->remaining=$imported_product->remaining - $cost;
        $imported_product->save();
        $imported = new ImportedSale();
        $imported->sale_id = $sale_id;
        $imported->imported_products_id = $request->imported_products_id;
        $imported->name = $request->name;
        $imported->price = $request->price;
        $imported->revenue = $revenue;
        $imported->save();
        return back();
    }

    public function delete($id){
        $imported = ImportedSale::find($id);
        $remaining=$imported->price-$imported->revenue;
        $imported->imported_product->remaining=$imported->imported_product->remaining+$remaining;
        $imported->imported_product->save();
        $imported->delete();
        return back();
    }

    public function toggle($id){
        $imported = ImportedSale::find($id);
        $imported->is_invoice=!$imported->is_invoice;
        $imported->save();
        return back();
    }

    public function producttoggle($id){
        $imported = Product_Sale::find($id);
        $imported->is_invoice=!$imported->is_invoice;
        $imported->save();
        return back();
    }
}
