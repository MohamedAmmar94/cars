<?php

namespace App\Http\Controllers;

use App\Biller;
use App\Customer;
use App\ExRepair;
use App\PartTransfer;
use App\Product_Sale;
use App\Sale;
use App\Supplier;
use App\Tax;
use App\Warehouse;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Auth;

class PartTransferController extends Controller
{

    public function transfers($sale_id){
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('stockorder-edit')){
            $workorders = Sale::where('workorder_status', 1)->orwhere('workorder_status', 2)->get();
            $parts = PartTransfer::where('transfer_from',$sale_id)->get();
            return view('workorder.part-transfers',compact('workorders','parts','sale_id' ));
        }
    }
    public function create($sale_id,Request $request){
        $transfer = new PartTransfer();
        $transfer->transfer_from = $sale_id;
        $transfer->transfer_to = $request->transfer_to;
        $transfer->name = $request->name;
        $transfer->cost = $request->cost;
        $transfer->price = $request->price;
        $transfer->status = 0;
        $transfer->save();
        return back();
    }

    public function toggle(Request $request){
        foreach ($request->parts as $part){
            $transferred = PartTransfer::find($part);
            $transferred->status = 1;
            $transferred->save();
        }
        return back();

    }
    public function delete($id){
        $transfer = PartTransfer::find($id);
        $transfer->delete();
        return back();
    }
}
