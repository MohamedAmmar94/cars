<?php

namespace App\Http\Controllers;

use App\Investment;
use App\InvestmentPayment;
use App\Investor;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Auth;

class InvestmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if ($role->hasPermissionTo('expenses-index')) {
            $permissions = Role::findByName($role->name)->permissions;
            foreach ($permissions as $permission)
                $all_permission[] = $permission->name;
            if (empty($all_permission))
                $all_permission[] = 'dummy text';

            $investors = Investor::where('is_active', 1)->get();

            $lims_expense_all=Investment::all();

            return view('investment.index', compact('investors','lims_expense_all', 'all_permission'));
        } else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = $request->all();

        $last_serial=Investment::where("reference_no",'LIKE',"#Inv-%")->orderBy("reference_no","desc")->first();
        if(!empty($last_serial)){
            $arr=explode("#Inv-",$last_serial->reference_no);
            //dd($arr);
            $new_serial=(int)$arr[1] +1;
            $new_serial=str_pad($new_serial, 5, '0', STR_PAD_LEFT);

            $new_arr=["#Inv-",$new_serial];
            $new_serial=implode($new_arr);
        }else{
            $new_serial="#Inv-00001";
        }


//        $data['reference_no'] = 'In-' . date("Ymd") . '-' . date("his");
        $data['reference_no'] = $new_serial;
        Investment::create($data);
        return redirect('investments')->with('message', 'Data inserted successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $role = Role::firstOrCreate(['id' => Auth::user()->role_id]);
        if ($role->hasPermissionTo('expenses-edit')) {
            $lims_expense_data = Investment::find($id);
            return $lims_expense_data;
        } else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $lims_expense_data = Investment::find($data['expense_id']);

        if($request->amount > $lims_expense_data->paid ) {
            $data['payment_status'] = 1;
        }

        $lims_expense_data->update($data);
        return redirect('investments')->with('message', 'Data updated successfully');
    }

    public function addpayment(Request $request, $id)
    {

        $investmentPayment=new InvestmentPayment;
        $investmentPayment->investment_id=$request->investment_id;
        $investmentPayment->amount=$request->amount;
        $investmentPayment->payment_method=$request->payment_method;
        $investmentPayment->cheque_no=$request->cheque_no;
        $investmentPayment->note=$request->note;
        $investmentPayment->save();


        $investment=Investment::find($request->investment_id);

        if($request->amount>0 and $request->amount<($investment->amount-$investment->paid))
        {
            $pyment_status=1;
        }
        elseif ($request->amount==($investment->amount-$investment->paid) )
        {
            $pyment_status=2;
        }
        else { $pyment_status=0;}

        $investment->paid=$investment->paid+$request->amount;
        $investment->payment_status=$pyment_status;
        $investment->save();

        return redirect('investments')->with('message', 'Data updated successfully');
    }

    public function deletePayment($id)
    {
        $payment=InvestmentPayment::find($id);

        if($payment->amount == $payment->investment->paid)
        {
            $pyment_status=0;
        }
        elseif ($payment->amount<$payment->investment->paid )
        {
            $pyment_status=1;
        }


        $payment->investment->paid=$payment->investment->paid-$payment->amount;
        $payment->investment->payment_status=$pyment_status;
        $payment->investment->save();

        $payment->delete();

        return redirect('investments')->with('message', 'Payment Deleted successfully');
    }

    public function deleteBySelection(Request $request)
    {
        $expense_id = $request['expenseIdArray'];
        foreach ($expense_id as $id) {
            $lims_expense_data = Investment::find($id);
            $lims_expense_data->delete();
        }
        return 'Investment deleted successfully!';
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $lims_expense_data = Investment::find($id);
        $lims_expense_data->delete();
        return redirect('investments')->with('not_permitted', 'Data deleted successfully');
    }
}
