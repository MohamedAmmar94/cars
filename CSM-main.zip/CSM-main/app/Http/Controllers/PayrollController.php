<?php

namespace App\Http\Controllers;

use App\Attendance;
use App\Leave;
use Illuminate\Http\Request;
use App\Account;
use App\Employee;
use App\Payroll;
use Auth;
use DB;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\Mail\UserNotification;
use Illuminate\Support\Facades\Mail;
use Carbon\Carbon;


class PayrollController extends Controller
{
    
    public function index()
    {
        $role = Role::find(Auth::user()->role_id);
        if($role->hasPermissionTo('payroll')){
            $lims_account_list = Account::where('is_active', true)->get();
            $lims_employee_list = Employee::where('is_active', true)->get();
            $general_setting = DB::table('general_settings')->latest()->first();
            if(Auth::user()->role_id > 2 && $general_setting->staff_access == 'own')
                $lims_payroll_all = Payroll::orderBy('id', 'desc')->where('user_id', Auth::id())->get();
            else
                $lims_payroll_all = Payroll::orderBy('id', 'desc')->get();

            return view('payroll.index', compact('lims_account_list', 'lims_employee_list', 'lims_payroll_all'));
        }
        else
            return redirect()->back()->with('not_permitted', 'Sorry! You are not allowed to access this module');
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $data = $request->all();
        $data['reference_no'] = 'payroll-' . date("Ymd") . '-'. date("his");
        $data['user_id'] = Auth::id();
        Payroll::create($data);
        $message = 'Payroll creared successfully';
        //collecting mail data
        $lims_employee_data = Employee::find($data['employee_id']);
        $mail_data['reference_no'] = $data['reference_no'];
        $mail_data['amount'] = $data['amount'];
        $mail_data['name'] = $lims_employee_data->name;
        $mail_data['email'] = $lims_employee_data->email;
        try{
            Mail::send( 'mail.payroll_details', $mail_data, function( $message ) use ($mail_data)
            {
                $message->to( $mail_data['email'] )->subject( 'Payroll Details' );
            });
        }
        catch(\Exception $e){
            $message = ' Payroll created successfully. Please setup your <a href="setting/mail_setting">mail setting</a> to send mail.';
        }

        return redirect('payroll')->with('message', $message);
    }

    public function edit($id)
    {
        //
    }


    public function generate(Request $request)
    {
        $year = date('Y');
        $month = $year."-".$request->month;
        $fulldate= $year."-".$request->month."-01";
        $daysmonth =  Carbon::parse($month)->daysInMonth;
        $allemployees=  Employee::where('is_active', true)->get();

        for($i=1; $i < $daysmonth + 1; ++$i) {
            if(Carbon::parse(Carbon::createFromDate($year, $request->month, $i)->format('Y-m-d'))->isFriday()
                || Carbon::parse(Carbon::createFromDate($year, $request->month, $i)->format('Y-m-d'))->isSaturday())
            {
//                echo "Overtime </br>";
            }
            else {
                $workingdates[] = \Carbon\Carbon::createFromDate($year, $request->month, $i)->format('Y-m-d');
            }
        }

        foreach ($allemployees as $employee)
        {
            $absencesdayes=0;
            $empSalary=$employee->salary;
            $dayCost=round($empSalary/30,2);
            $hourCost=round($dayCost/8,2);

            $sumLates=Attendance::whereMonth('date',$request->month)
                ->whereYear('date',$year)
                ->where('employee_id',$employee->id)->get()->sum('late');

            $sumOvertime=Attendance::whereMonth('date',$request->month)
                ->whereYear('date',$year)
                ->where('employee_id',$employee->id)->get()->sum('overtime');


            foreach ($workingdates as $workingdate)
            {
                $attendancecheck = Attendance::whereDate('date', $workingdate)->where('employee_id', $employee->id)->get()->count();
                $leavescheck = Leave::whereDate('date', $workingdate)->where('employee_id', $employee->id)->get()->count();
                if ($attendancecheck == 0 and $leavescheck==0) {
                    $absencesdayes ++;
                }

            }
            $latescost=round(($sumLates/60)*$hourCost,2)*2;
            $absencescost=round($absencesdayes*$dayCost)*2;
            $overtimecost=round(($sumOvertime/60)*$hourCost,2)*1.5;

            $netsalary = $empSalary+$overtimecost-$latescost-$absencescost;

            $payrollcaheck=Payroll::whereDate('date',$fulldate)->where('employee_id',$employee->id)->get()->count();
          if($payrollcaheck == 0) {
              /////// Add Payroll ///////////////////////////
              $newpayroll = new Payroll();
              $newpayroll->date = $fulldate;
              $newpayroll->reference_no = 'payroll-' . date("Ymd") . '-' . date("his");
              $newpayroll->employee_id = $employee->id;
              $newpayroll->account_id = 1;
              $newpayroll->user_id = Auth::id();
              $newpayroll->penalties = $latescost + $absencescost;
              $newpayroll->overtime = $overtimecost;
              $newpayroll->amount = $netsalary;
              $newpayroll->save();
          }
        }

        return redirect('payroll')->with('message', 'Payrolls generated successfully');
    }

    public function pay($id)
    {
        $payroll=Payroll::find($id);
        $payroll->paying_method='Cash';
        $payroll->status='Paid';
        $payroll->save();
        return redirect('payroll')->with('message', 'Payroll Paid successfully');
    }

    public function update(Request $request, $id)
    {
        $data = $request->all();
        $lims_payroll_data = Payroll::find($data['payroll_id']);
        $lims_payroll_data->update($data);
        return redirect('payroll')->with('message', 'Payroll updated successfully');
    }

    public function deleteBySelection(Request $request)
    {
        $payroll_id = $request['payrollIdArray'];
        foreach ($payroll_id as $id) {
            $lims_payroll_data = Payroll::find($id);
            $lims_payroll_data->delete();
        }
        return 'Payroll deleted successfully!';
    }

    public function destroy($id)
    {
        $lims_payroll_data = Payroll::find($id);
        $lims_payroll_data->delete();
        return redirect('payroll')->with('not_permitted', 'Payroll deleted successfully');
    }
}
