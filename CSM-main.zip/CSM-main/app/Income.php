<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Income extends Model
{
    protected $fillable =[
        "reference_no", "income_category_id", "warehouse_id", "account_id", "user_id", "amount","payment_method","cheque_no", "note"
    ];

    public function warehouse()
    {
        return $this->belongsTo('App\Warehouse');
    }

    public function incomeCategory() {
        return $this->belongsTo(IncomeCategory::class);
    }
}
