<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AssetPayment extends Model
{
    protected $fillable = [
        "asset_id", "amount", "payment_method", "cheque_no", "note"
    ];

    public function asset()
    {
        return $this->belongsTo(Asset::class);
    }
}
