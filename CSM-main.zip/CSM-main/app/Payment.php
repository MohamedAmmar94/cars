<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    protected $fillable =[

        "purchase_id", "user_id", "sale_id", "account_id", "payment_reference", "amount", "change", "paying_method", "payment_note"
    ];

    public function sale()
    {
        return $this->belongsTo(Sale::class,'sale_id');
    }

    public function purchase()
    {
        return $this->belongsTo(Purchase::class);
    }
}
