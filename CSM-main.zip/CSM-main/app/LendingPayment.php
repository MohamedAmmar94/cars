<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LendingPayment extends Model
{
    protected $fillable = [
        "lending_id", "amount", "payment_method", "cheque_no", "note"
    ];

    public function lending()
    {
        return $this->belongsTo(Lending::class);
    }
}
