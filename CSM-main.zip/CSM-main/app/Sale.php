<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sale extends Model
{
    protected $fillable =[

        "reference_no","invoice_no", "user_id", "customer_id", "car_id","warehouse_id",
        "biller_id", "quotation_id", "item", "total_qty", "total_discount",
        "total_tax", "total_price", "order_tax_rate", "order_tax", "order_discount",
        "coupon_id", "coupon_discount", "shipping_cost", "grand_total", "sale_status",
        "payment_status", "paid_amount", "document", "sale_note", "staff_note", "mill_age",
        "type", "workorder_status","consumables",'vat','wht',"wht-s"

    ];

    public function biller()
    {
    	return $this->belongsTo('App\Biller');
    }

    public function customer()
    {
    	return $this->belongsTo('App\Customer');
    }

    public function warehouse()
    {
    	return $this->belongsTo('App\Warehouse');
    }

    public function user()
    {
    	return $this->belongsTo('App\User');
    }

    public function returns()
    {
    	return $this->hasMany(Returns::class);
    }

    public function customercar()
    {
        return $this->belongsTo(CustomerCar::class,'car_id');
    }
	public function product()
    {
        return $this->belongsToMany('App\Product', 'product_sales', 'sale_id', 'product_id');
    }

    public function product_sales()
    {
        return $this->hasMany(Product_Sale::class);
    }

    public function exrepairs(){
        return $this->hasMany(ExRepair::class,'sale_id');
    }

    public function transfer_from(){
        return $this->hasMany(PartTransfer::class,'transfer_from');
    }
    public function transfer_hold(){
        return $this->hasMany(PartTransfer::class,'transfer_from')->where('status',0);
    }

    public function transfer_to(){
        return $this->hasMany(PartTransfer::class,'transfer_to');
    }

    public function imported()
    {
        return $this->hasMany(ImportedSale::class,'sale_id');
    }


}
