<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable =[

        "name", 'image', "parent_id", "is_active",'code'
    ];

    public function product()
    {
    	return $this->hasMany('App\Product');
    }

    public function models()
    {
    	return $this->hasMany(Category::class,'parent_id');
    }

    public function canDeleted()
    {
        $products= Product::where('category_id', $this->id)->whereHas('purchases')->whereHas('sales')->get();
        if($products->count()>0)
        return  true;
        return false;
    }
}
