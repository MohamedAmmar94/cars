<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvestmentPayment extends Model
{
    protected $fillable = [
         "investment_id", "amount", "payment_method", "cheque_no", "note"
    ];

    public function investment()
    {
        return $this->belongsTo(Investment::class);
    }
}
