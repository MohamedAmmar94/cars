<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PartTransfer extends Model
{
    public function workorder(){
        return $this->belongsTo(Sale::class,'transfer_to');
    }
}
