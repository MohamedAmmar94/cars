<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExRepair extends Model
{
    public function supplier(){
        return $this->belongsTo(Supplier::class);
    }
}
