<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerCar extends Model
{
    protected $fillable =[
        "customer_id","customer_branch_id","chassis","category_id","model","year", "mileage", "plate","license"
    ];
    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function cutomerbranch()
    {
        return $this->belongsTo(CustomerBranch::class,'customer_branch_id');
    }


    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function carmodel()
    {
        return $this->belongsTo(Category::class,'model','id');
    }

	public function backlog()
    {
    	return $this->hasMany('App\Backlog',"car_id","id");
    }
}
