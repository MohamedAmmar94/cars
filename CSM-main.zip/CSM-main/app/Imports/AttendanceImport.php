<?php

namespace App\Imports;

use App\Attendance;
use App\Employee;
use App\HrmSetting;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Auth;
use Carbon\Carbon;

class AttendanceImport implements ToCollection,WithHeadingRow
{


    public function collection(Collection $rows)
    {
        $hrmsettings=HrmSetting::latest()->first();
        $standardtimein=Carbon::parse($hrmsettings->checkin);
        $standardtimeout=Carbon::parse($hrmsettings->checkout);

//        dd($standardtimeout->diffInHours($standardtimein));
        foreach ($rows as $row)
        {
            $employee=Employee::where('fp_id',$row['id'])->first();
            if(isset($employee->id)) {
                $date = date("Y-m-d", strtotime($row['date']));
                $TimeIn = date("H:i:s", strtotime($row['timein']));
                $TimeOut = date("H:i:s", strtotime($row['timeout']));
                $late=0;
                $overtime=0;
                if(Carbon::parse($date)->isFriday() || Carbon::parse($date)->isSaturday()) {
                        $overtime = Carbon::parse($TimeOut)->diffInMinutes(Carbon::parse($TimeIn));
                }
                else {
                    if (Carbon::parse($standardtimein) < Carbon::parse($TimeIn)) {
                        $late = Carbon::parse($TimeIn)->diffInMinutes(Carbon::parse($standardtimein)->addMinutes(15));
                    }
                    if (Carbon::parse($TimeOut) < Carbon::parse($standardtimeout)) {
                        $late += Carbon::parse($standardtimeout)->diffInMinutes(Carbon::parse($TimeOut));
                    }

                    if (Carbon::parse($TimeOut) > Carbon::parse($standardtimeout)) {
                        $overtime += Carbon::parse($TimeOut)->diffInMinutes(Carbon::parse($standardtimeout)->addMinutes(30));
                    }
                }

                $attendance_check = Attendance::where('employee_id', $employee->id)->whereDate('date', $date)
                    ->whereTime('checkin', $TimeIn)->whereTime('checkout', $TimeOut)->get()->count();
                if ($attendance_check == 0) {
                    $attendance = new Attendance;
                    $attendance->date = $date;
                    $attendance->employee_id = $employee->id;
                    $attendance->user_id = Auth::User()->id;
                    $attendance->checkin = $TimeIn;
                    $attendance->checkout = $TimeOut;
                    $attendance->late = $late;
                    $attendance->overtime = $overtime;
                    $attendance->status = 1;
                    $attendance->save();
                }
            }
        }
    }
}
